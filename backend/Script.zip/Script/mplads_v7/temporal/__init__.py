"""
Temporal information boundary subpackage.
"""
